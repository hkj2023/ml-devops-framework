import logging

from mlflow import MlflowException
from mlflow.gateway.config import Provider
from mlflow.gateway.providers import BaseProvider
from mlflow.utils.plugins import get_entry_points
from mlflow.utils.provider_filter import is_provider_allowed

_logger = logging.getLogger(__name__)


class ProviderRegistry:
    def __init__(self):
        self._providers: dict[str | Provider, type[BaseProvider]] = {}

    def register(self, name: str, provider: type[BaseProvider]):
        if name in self._providers:
            raise MlflowException.invalid_parameter_value(
                f"Provider {name} is already registered: {self._providers[name]}"
            )
        self._providers[name] = provider

    def get(self, name: str) -> type[BaseProvider]:
        if name not in self._providers:
            raise MlflowException.invalid_parameter_value(f"Provider '{name}' not found")

        if not is_provider_allowed(name):
            _logger.debug(
                "Provider '%s' blocked by MLFLOW_GATEWAY_ALLOWED_PROVIDERS",
                name,
            )
            raise MlflowException.invalid_parameter_value(
                f"Provider '{name}' is not allowed by the current gateway provider policy."
            )
        return self._providers[name]

    def keys(self):
        return list(self._providers.keys())


def _register_default_providers(registry: ProviderRegistry):
    from mlflow.gateway.providers.ai21labs import AI21LabsProvider
    from mlflow.gateway.providers.anthropic import AnthropicProvider
    from mlflow.gateway.providers.bedrock import AmazonBedrockProvider
    from mlflow.gateway.providers.cohere import CohereProvider
    from mlflow.gateway.providers.databricks import DatabricksProvider
    from mlflow.gateway.providers.deepseek import DeepSeekProvider
    from mlflow.gateway.providers.gemini import GeminiProvider
    from mlflow.gateway.providers.groq import GroqProvider
    from mlflow.gateway.providers.huggingface import HFTextGenerationInferenceServerProvider
    from mlflow.gateway.providers.litellm import LiteLLMProvider
    from mlflow.gateway.providers.mistral import MistralProvider
    from mlflow.gateway.providers.mlflow import MlflowModelServingProvider
    from mlflow.gateway.providers.mosaicml import MosaicMLProvider
    from mlflow.gateway.providers.ollama import OllamaProvider
    from mlflow.gateway.providers.openai import OpenAIProvider
    from mlflow.gateway.providers.openrouter import OpenRouterProvider
    from mlflow.gateway.providers.palm import PaLMProvider
    from mlflow.gateway.providers.portkey import PortkeyProvider
    from mlflow.gateway.providers.togetherai import TogetherAIProvider
    from mlflow.gateway.providers.vertex_ai import VertexAIProvider
    from mlflow.gateway.providers.xai import XAIProvider

    registry.register(Provider.AI21LABS, AI21LabsProvider)
    registry.register(Provider.AMAZON_BEDROCK, AmazonBedrockProvider)
    registry.register(Provider.ANTHROPIC, AnthropicProvider)
    registry.register(Provider.AZURE, OpenAIProvider)
    registry.register(Provider.BEDROCK, AmazonBedrockProvider)
    registry.register(Provider.COHERE, CohereProvider)
    registry.register(Provider.DATABRICKS, DatabricksProvider)
    registry.register(Provider.DATABRICKS_MODEL_SERVING, DatabricksProvider)
    registry.register(Provider.DEEPSEEK, DeepSeekProvider)
    registry.register(Provider.GEMINI, GeminiProvider)
    registry.register(Provider.GROQ, GroqProvider)
    registry.register(
        Provider.HUGGINGFACE_TEXT_GENERATION_INFERENCE, HFTextGenerationInferenceServerProvider
    )
    registry.register(Provider.LITELLM, LiteLLMProvider)
    registry.register(Provider.MISTRAL, MistralProvider)
    registry.register(Provider.MLFLOW_MODEL_SERVING, MlflowModelServingProvider)
    registry.register(Provider.MOSAICML, MosaicMLProvider)
    registry.register(Provider.OLLAMA, OllamaProvider)
    registry.register(Provider.OPENAI, OpenAIProvider)
    registry.register(Provider.OPENROUTER, OpenRouterProvider)
    registry.register(Provider.PALM, PaLMProvider)
    registry.register(Provider.PORTKEY, PortkeyProvider)
    registry.register(Provider.TOGETHERAI, TogetherAIProvider)
    registry.register(Provider.VERTEX_AI, VertexAIProvider)
    registry.register(Provider.XAI, XAIProvider)


def _register_plugin_providers(registry: ProviderRegistry):
    providers = get_entry_points("mlflow.gateway.providers")
    for p in providers:
        cls = p.load()
        registry.register(p.name, cls)


def is_supported_provider(name: str) -> bool:
    return name in provider_registry.keys()


provider_registry = ProviderRegistry()
_register_default_providers(provider_registry)
_register_plugin_providers(provider_registry)
